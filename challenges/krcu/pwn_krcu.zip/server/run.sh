#!/bin/bash
tmpDir=$(mktemp -d /tmp/exp.XXXXX)

cp rootfs.img $tmpDir/
cp flag.txt $tmpDir/

echo "Enter the URL of your exploit binary (it will be saved to /tmp/exp):  "
read url

wget -O "$tmpDir/exp" "$url" && \
chmod +x $tmpDir/exp


timeout 30 qemu-system-x86_64 -m 1G -nographic -no-reboot \
  -enable-kvm -cpu host,+smep,+smap -smp 2 \
  -kernel ./bzImage \
  -nic user,model=virtio-net-pci \
  -drive file=$tmpDir/rootfs.img,if=virtio,cache=none,aio=native,format=raw \
  -drive file=$tmpDir/exp,if=virtio,cache=none,aio=native,format=raw \
  -drive file=$tmpDir/flag.txt,if=virtio,cache=none,aio=native,format=raw \
  -append "kaslr console=ttyS0 root=/dev/vda rw quiet" -monitor /dev/null

rm -rf $tmpDir
